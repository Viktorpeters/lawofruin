"use client";

/* What opens when the home-screen icon is tapped.
   First open: the splash (the hourglass turns, then flies onto the cover), then the cover,
   which the reader swings open into the book.
   Every open after that: straight to the page they stopped on. No splash, no cover.
   The words come from the server, in the reader's language, and only what this reader may read.
   Over the book: the language button and the profile icon top right; Ask and the tray bottom right. */

import { useCallback, useEffect, useRef, useState } from "react";
import Book, { type BookHandle, type PageInfo } from "./Book";
import Splash from "./Splash";
import Tray from "./Tray";
import Panel, { type PanelId } from "./Panels";
import { WhoCard, WordCard } from "./Cards";
import Coach from "./Coach";
import LawSheet from "./LawSheet";
import { setBook, VERSION } from "@/lib/book/content";
import { useBook, useMe } from "@/lib/queries";
import { useSignOut } from "@/lib/actions";
import { LANGS, savedLang, saveLang, t, type Lang } from "@/lib/i18n";
import s from "./bookapp.module.css";

const SEEN_KEY = "lor-seen";     // set once the reader has opened the cover
const FS_KEY = "lor-fs";
const HAND_KEY = "lor-hand";
const GUIDE_KEY = "lor-guide";  // set once the reading guide has been seen
const SPLASH_MIN = 1700;         // the hourglass turns at least this long before it flies

function get(key: string) {
  try { return localStorage.getItem(key); } catch { return null; }
}
function set(key: string, v: string | null) {
  try { if (v === null) localStorage.removeItem(key); else localStorage.setItem(key, v); } catch { /* ignore */ }
}

export default function BookApp() {
  const book = useRef<BookHandle>(null);
  const [boot, setBoot] = useState<null | { returning: boolean }>(null);
  const [fontSize, setFontSizeState] = useState(16);
  const [left, setLeftState] = useState(false);
  const [ready, setReady] = useState(false);
  const [minTime, setMinTime] = useState(false);
  const [splashTarget, setSplashTarget] = useState<DOMRect | null>(null);
  const [splash, setSplash] = useState(false);
  const [page, setPage] = useState<PageInfo | null>(null);
  const [panel, setPanel] = useState<PanelId | null>(null);
  const [who, setWho] = useState<string | null>(null);
  const [word, setWord] = useState<{ id: string; at: DOMRect } | null>(null);
  const [guide, setGuide] = useState(false);
  const [law, setLaw] = useState<number | null>(null);
  const [lang, setLangState] = useState<Lang>("en");
  const [langOpen, setLangOpen] = useState(false);
  const [version, setVersion] = useState(0);
  const whoFromList = useRef(false);   // a card opened from the Who's Who list goes back to the list

  // the reader (null when signed out) and the book they may read, in their language
  const me = useMe().data ?? null;
  const words = useBook(lang, !!boot);
  const owner = words.data?.owner ?? false;
  const offline = words.isError && version === 0;
  const signOutNow = useSignOut();

  // a new book arrived (first load, another language, a sign-in): hand it to the reader
  useEffect(() => {
    if (!words.data) return;
    setBook(words.data);
    setVersion(VERSION);
  }, [words.data]);

  // read the saved settings once, in the browser, then fetch the reader and the book
  useEffect(() => {
    const raf = requestAnimationFrame(() => {
      const fs = Number(get(FS_KEY));
      if (fs === 15 || fs === 16 || fs === 17.5) setFontSizeState(fs);
      setLeftState(get(HAND_KEY) === "left");
      const l = savedLang();
      setLangState(l);
      const returning = get(SEEN_KEY) === "1" && !!get("lor-place");
      setSplash(!returning);
      setBoot({ returning });
    });
    return () => cancelAnimationFrame(raf);
  }, []);

  // no signal and no saved book: the splash steps aside so the reader sees why
  useEffect(() => {
    if (offline && version === 0) setSplash(false);
  }, [offline, version]);

  // the splash turns for a moment before it may fly
  useEffect(() => {
    if (!splash) return;
    const t = window.setTimeout(() => setMinTime(true), SPLASH_MIN);
    return () => window.clearTimeout(t);
  }, [splash]);

  // the book is ready and the hourglass has turned: fly it onto the cover
  useEffect(() => {
    if (!splash || !ready || !minTime || splashTarget) return;
    const raf = requestAnimationFrame(() => setSplashTarget(book.current?.emblemRect() ?? new DOMRect(innerWidth / 2 - 20, innerHeight / 2 - 30, 40, 64)));
    return () => cancelAnimationFrame(raf);
  }, [splash, ready, minTime, splashTarget]);

  const onPage = useCallback((info: PageInfo) => {
    setPage(info);
    if (info.index > 0) set(SEEN_KEY, "1");
    // the first time the cover is opened, show how to turn the pages
    if (info.index > 0 && get(GUIDE_KEY) !== "1") setGuide(true);
  }, []);
  const onReady = useCallback(() => setReady(true), []);
  const onWho = useCallback((id: string) => { setWord(null); whoFromList.current = false; setWho(id); }, []);
  const onWord = useCallback((id: string, at: DOMRect) => setWord({ id, at }), []);
  const endSplash = useCallback(() => setSplash(false), []);
  const endGuide = useCallback(() => { set(GUIDE_KEY, "1"); setGuide(false); }, []);

  const jump = useCallback((sec: string) => {
    setPanel(null);
    setWho(null);
    whoFromList.current = false;
    // "law-1" and the like open that law's sheet; everything else is a page in the book
    if (sec.startsWith("law-")) { setLaw(Number(sec.slice(4))); return; }
    setLaw(null);
    book.current?.jumpTo(sec);
  }, []);

  const closeWho = useCallback(() => {
    setWho(null);
    // opened from the list: the list comes back, at the same name and the same search
    if (whoFromList.current) { whoFromList.current = false; setPanel("whoswho"); }
  }, []);

  const setFontSize = useCallback((n: number) => { set(FS_KEY, String(n)); setFontSizeState(n); }, []);
  const setLeft = useCallback((v: boolean) => { set(HAND_KEY, v ? "left" : null); setLeftState(v); }, []);
  const restart = useCallback(() => { setPanel(null); book.current?.flipTo(0); }, []);

  const chooseLang = useCallback((l: Lang) => {
    setLangOpen(false);
    saveLang(l);
    setLangState(l);
    document.documentElement.lang = l;   // the book for this language is fetched by useBook
  }, []);

  const signOut = useCallback(() => { signOutNow(); setPanel(null); }, [signOutNow]);

  if (!boot) return <main className={s.app} />;

  // the book shows once it is built: at once for a returning reader, behind the flight for a new one
  const showBook = ready && (!splash || !!splashTarget);
  const dark = page?.dark ?? true;
  const current = LANGS.find((x) => x.code === lang)!;

  return (
    <main className={s.app}>
      {version > 0 && (
        <Book
          ref={book}
          fontSize={fontSize}
          version={version}
          visible={showBook}
          startFromPlace={boot.returning}
          onReady={onReady}
          onPage={onPage}
          onWho={onWho}
          onWord={onWord}
          onLaw={setLaw}
        />
      )}

      {offline && version === 0 && !splash && (
        <div className={s.offline}>
          <p>{t(lang, "noConnection")}</p>
          <button type="button" onClick={() => words.refetch()}>{t(lang, "retry")}</button>
        </div>
      )}

      {showBook && (
        <>
          <button type="button" className={`${s.lang} ${dark ? s.onDark : ""}`} onClick={() => setLangOpen((o) => !o)} aria-label={t(lang, "language")} aria-expanded={langOpen}>
            {current.short}
          </button>
          {langOpen && (
            <>
              <div className={s.langScrim} onClick={() => setLangOpen(false)} aria-hidden="true" />
              <ul className={s.langList} role="listbox" aria-label={t(lang, "language")}>
                {LANGS.map((x) => (
                  <li key={x.code}>
                    <button type="button" role="option" aria-selected={x.code === lang} onClick={() => chooseLang(x.code)}>
                      <span>{x.short}</span>{x.name}
                    </button>
                  </li>
                ))}
              </ul>
            </>
          )}
          <button type="button" className={`${s.profile} ${dark ? s.onDark : ""} ${me ? s.signedIn : ""}`} onClick={() => setPanel("account")} aria-label={t(lang, "account")}>
            {me ? (
              // signed in: the first letter of their email, in gold
              <span className={s.initial} aria-hidden="true">{(me.name || me.email).trim().charAt(0).toUpperCase()}</span>
            ) : (
              <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="5.5" r="3" /><path d="M2.5 14.5c.8-3 3-4.5 5.5-4.5s4.7 1.5 5.5 4.5" /></svg>
            )}
          </button>
          {/* on the closed cover: only the hint, so nothing sits on the corner the reader lifts */}
          {page?.index === 0 || guide ? (
            !panel && !guide && <p className={s.hint}>{t(lang, "swipe")}</p>
          ) : (
            <Tray
              left={left}
              light={dark}
              lang={lang}
              onChoose={(id) => { setWho(null); setWord(null); setPanel(id); }}
              onAsk={() => { setWho(null); setWord(null); setPanel("ask"); }}
            />
          )}
        </>
      )}

      {panel && (
        <Panel
          id={panel}
          lang={lang}
          me={me}
          owner={owner}
          section={page?.secs[0]}
          law={law ?? undefined}
          onClose={() => setPanel(null)}
          onOpen={setPanel}
          onJump={jump}
          onWho={(id) => { setPanel(null); whoFromList.current = true; setWho(id); }}
          onSignOut={signOut}
          onLang={chooseLang}
          fontSize={fontSize}
          setFontSize={setFontSize}
          left={left}
          setLeft={setLeft}
          onRestart={restart}
          onGuide={() => { setPanel(null); setGuide(true); }}
        />
      )}
      {law !== null && <LawSheet n={law} onClose={() => setLaw(null)} onWho={onWho} onWord={onWord} />}
      {who && <WhoCard id={who} onClose={closeWho} onJump={jump} />}
      {word && <WordCard id={word.id} at={word.at} onClose={() => setWord(null)} />}

      {guide && showBook && <Coach onDone={endGuide} />}
      {splash && <Splash target={splashTarget} onDone={endSplash} />}
    </main>
  );
}
